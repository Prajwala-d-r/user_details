import { Component, OnInit } from '@angular/core';
import { User } from '../model/User';
import { UserService } from '../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

usersList : Array<User> = []
userInput : string = '';
validEmail: boolean = true;

  constructor(
    private userService: UserService,
    private router: Router,
     private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.authenticate();
  }

  public authenticate(){
    this.userService.getAllUsers().subscribe(response => {
       let usersList : any =  response;
        this.usersList = usersList;
       console.log(this.usersList)
    })
  }

  public userHomePage(){
    console.log(this.userInput)
    this.validEmail=false;
    this.usersList.forEach(user => {
      if(user.email==this.userInput){
        this.validEmail=true;
        this.userService.userLogin=true;
      }
    })

  if(this.validEmail)
    this.router.navigate(['homePage']);

  }


}
