import { Component, OnInit,Input } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../model/User';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  usersList: Array<User> =[];
  userSelectedList: Array<User> =[];

  constructor(private userService: UserService,
    private router: Router,
     private route: ActivatedRoute) { }

  ngOnInit(): void {
    if(this.userService.userLogin==false){
      this.router.navigate(['login']);
    }
    
    this.userService.getAllUsers().subscribe(response => {
      let usersList : any =  response;
       this.usersList = usersList;
   })
  }

public mouseEnter(userId : number){

  console.log('id selected  ',userId)
  this.usersList.forEach(user =>{
    if(user.id==userId){
      this.userSelectedList.push(user)
    }
  })
}

public mouseLeave(userId : number){

  console.log('id removed  ',userId)
  this.userSelectedList = [];
}

}
